# ds_vineela_shetty

This folder contains the submission package for the Data Science assignment.

## Structure

- notebook_1.ipynb     # Colab-ready notebook (Quick EDA + Cohort & Risk Analysis)
- csv_files/           # Processed CSVs including merged_trades_sentiment.csv
- outputs/             # Visual outputs (png)
- ds_report.pdf        # Short PDF summary

Candidate: Vineela Shetty
